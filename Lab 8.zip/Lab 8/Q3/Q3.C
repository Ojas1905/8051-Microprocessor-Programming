#include <at89c5131.h>
#include "lcd.h"

sbit begin = P1^0;
sbit led = P3^6;
int minutes, minutes0, minutes1, seconds, seconds1, seconds0, count = 0, i, time[4];
unsigned char number[10] = "0123456789";

void timer1_isr() interrupt 3{
	led = ~led;
	TH1 = 0xBE;
	TL1 = 0XE8;
	TR1 = 1;
}

void timer0_isr() interrupt 1{
	TH0 = 0XFF;
	TL0 = 0XC4;
	TR0 = 1;
	count++;
}

void start(){
	if(begin== 1){
		TR0 = 1;
		return;
	}
	else{
		TR0 = 0;
		return;
	}
}

void main(){
	led = 1;
	TMOD = 0X15;
	TH1 = 0XBE;
	TL1 = 0XE8;
	TH0 = 0XFF;
	TL0 = 0XC4;
	EA = 1;
	ET1 = 1;
	TR1 = 1;
	ET0 = 1;
	lcd_init();

	
	while(1){
		if(begin== 1){
			TR0 = 1;
		}
		else{
			TR0 = 0;
		}
		minutes = count/60;
		seconds = count % 60;
		minutes1 = minutes/10;
		minutes0 = minutes % 10;
		seconds1 = seconds/10;
		seconds0 = seconds % 10;
		lcd_cmd(0x80);
		msdelay(4);
		
		lcd_write_char(number[minutes1]);
		lcd_cmd(0x06);
		msdelay(4);
		lcd_write_char(number[minutes0]);
		lcd_cmd(0x06);
		msdelay(4);
		lcd_write_char(':');
		lcd_cmd(0x06);
		msdelay(4);
		lcd_write_char(number[seconds1]);
		lcd_cmd(0x06);
		msdelay(4);
		lcd_write_char(number[seconds0]);
		lcd_cmd(0x80);

	
	}
	
}