#include <at89c5131.h>
#include "lcd.h"

code unsigned char msg1[] = "  ENTER PASSWORD";
code unsigned char msg2[] = "CORRECT PASSWORD";
code unsigned char msg3[] = " ACCESS GRANTED";
code unsigned char msg4[] = "WRONG PASSWORD";
code unsigned char msg5[] = "  ACCESS DENIED";

unsigned char password[8]="15A8*D6#";
code unsigned char row0[]="123A";
code unsigned char row1[]="456B";
code unsigned char row2[]="789C";
code unsigned char row3[]="*0#D";
unsigned char pwd[8];
char character;

int c, column, d, row, i=0, b, a, check,j;


int take_input(){
	a = 0xF0;
	
	while(a != 0x0F){
		a = P3 & 0x0F;
		a = a & 0x0F;
	}
	
	while(a == 0x0F){
		a = P3 & 0x0F;
	}
		
	msdelay(20);
	a = P3 & 0x0F;
	return a;
}

char matrix(){
	int row_id, column_id;
	char y;
	row_id = row;
	column_id = column;
	
	if(row == 0){
		y = row0[column_id];
	}
	else if(row == 1){
		y = row1[column_id];
	}
	else if(row == 2){
		y = row2[column_id];
	}
	else{
		y = row3[column_id];
	}
	
	return y;
}

void key(){
	c = b;
	b = b & 0x07;
	if(b == c){
		column = 0;
	}
		
	b = c;
	b = b & 0x0B;
	if(b == c){
		column = 1;
	}
		
	b = c;
	b = b & 0x0D;
	if(b == c){
		column = 2;
	}
		
	b = c;
	b = b & 0x0E;
	if(b == c){
		column = 3;
	}

	P3_7 = 1;
	P3_6 = 1;
	P3_5 = 1;
	P3_4 = 0;
	d = P3 & 0x0F;
	if(d != 0x0F){
		row = 0;
	}
		
	P3_7 = 1;
	P3_6 = 1;
	P3_5 = 0;
	P3_4 = 1;
	d = P3 & 0x0F;
	if(d != 0x0F){
		row = 1;
	}
		
	P3_7 = 1;
	P3_6 = 0;
	P3_5 = 1;
	P3_4 = 1;
	d = P3 & 0x0F;
	if(d != 0x0F){
		row = 2;
	}
		
	P3_7 = 0;
	P3_6 = 1;
	P3_5 = 1;
	P3_4 = 1;
	d = P3 & 0x0F;
	if(d != 0x0F){
		row = 3;
	}
		
	character = matrix();
	pwd[i] = character;
	//lcd_cmd(0xC0);
	
	//lcd_write_char(character);
	//lcd_cmd(0x06);
}
	

void main(){

	lcd_init();
	lcd_cmd(0x80);
	msdelay(4);
	lcd_write_string(msg1);
	msdelay(4);
	lcd_cmd(0xC0);
	P3 = 0x0F;
	a = 0x0F;
	while(a == 0x0F){
		a = P3 & 0x0F;
	}
	
	msdelay(20);
	a = P3 & 0x0F;
	b = a;
	key();
	
	for(i = 1; i < 8; i++){
		P3 = 0x0F;
		b = take_input();
		
		while(b == 0x0F){
			P3 = 0x0F;
			b = take_input();
		}
		key();
		lcd_write_char(pwd[i]);
		
	}
	check = 1;
	for(j=0;j<8;j++)
	{
		if((pwd[j]!=password[j]) & check == 1)
		{
			check = 0;
		}	
		else{continue;}
	}
	if(check == 1){
		lcd_init();
		lcd_cmd(0x80);
		msdelay(4);
		lcd_write_string(msg2);
		lcd_cmd(0xC0);
		msdelay(4);
		lcd_write_string(msg3);
		while(1);
	}
	if(check == 0){
		lcd_init();
		lcd_cmd(0x80);
		msdelay(4);
		lcd_write_string(msg4);
		lcd_cmd(0xC0);
		msdelay(4);
		lcd_write_string(msg5);
		while(1);
	}
}