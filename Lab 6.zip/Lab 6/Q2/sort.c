#include <at89c5131.h>
#include "lcd.h"

code unsigned char display_msg1[]=" START PROGRAM";						//Display msg on 1st line of lcd
code unsigned char display_msg2[]=" FIRST INPUT      ";						//Display msg on 1st line of lcd
code unsigned char display_msg3[]="  NEXT INPUT      ";						//Display msg on 1st line of lcd
code unsigned char display_msg4[]="   SORTING...   ";						//Display msg on 1st line of lcd
code unsigned char display_msg5[]="   SORTING   ";						//Display msg on 1st line of lcd
code unsigned char display_msg6[]="   COMPLETED   ";						//Display msg on 1st line of lcd
code unsigned char display_msg7[]="   NUMBER TO BE   ";						//Display msg on 1st line of lcd
code unsigned char display_msg8[]="   SEARCHED   ";						//Display msg on 1st line of lcd
code unsigned char display_msg9[]="  THE INDEX IS  ";						//Display msg on 1st line of lcd
code unsigned char display_msg10[]="   NUMBER   ";						//Display msg on 1st line of lcd
code unsigned char display_msg11[]="   NOT FOUND  ";						//Display msg on 1st line of lcd


unsigned char get_input()
{
	unsigned char P1_val;
	P1 = 0x0F;
	P1_val = P1;

	return P1_val;
}

unsigned char swap(unsigned char a)
{	
	unsigned char higher_nibbles = (a & 0xf0) >> 4;
	unsigned char lower_nibbles = (a & 0x0f) << 4;
	
	return (higher_nibbles | lower_nibbles);
}

void led_display(unsigned char b)
{	
	unsigned char swapped;
	P1 = 0x00;	
	swapped	= swap(b);		
	P1 = swapped;
}	

void sort(unsigned char input_array[]){
	int i, j;
	unsigned char temp;
	for(i=1;i<6;i++)
	{
		for(j=0;j<4;j++)
		{
			if(input_array[j] > input_array[j+1])
			{
				temp = input_array[j];
				input_array[j] = input_array[j+1];
				input_array[j+1] = temp;
			}
		}
	}
}

void main()
{
	int i=0;
	int found, index;
	unsigned char number;
	unsigned char input_array[5];
	lcd_init();
	lcd_cmd(0x80);													//Move cursor to first line
	msdelay(4);
	lcd_write_string(display_msg1);
	P1 = 0x00;
	msdelay(5000);
  lcd_cmd(0x01);
	lcd_init();
	lcd_cmd(0x80);
	lcd_write_string(display_msg2);
	msdelay(5000);
	
	input_array[0]=get_input();
	led_display(input_array[0]);
	lcd_init();
	lcd_cmd(0x80);
	lcd_write_string(display_msg3);
	msdelay(5000);
	
	lcd_init();
	lcd_cmd(0x01);
	input_array[1]=get_input();
	led_display(input_array[1]);
	lcd_init();
	lcd_cmd(0x80);
	lcd_write_string(display_msg3);
	msdelay(5000);

	input_array[2]=get_input();
	led_display(input_array[2]);
	lcd_init();
	lcd_cmd(0x80);
	lcd_write_string(display_msg3);
	msdelay(5000);

	input_array[3]=get_input();
	led_display(input_array[3]);
	lcd_init();
	lcd_cmd(0x80);
	lcd_write_string(display_msg3);
	msdelay(5000);
	
	lcd_init();
	lcd_cmd(0x01);
	input_array[4]=get_input();
	led_display(input_array[4]);
	lcd_init();
	lcd_cmd(0x80);
	lcd_write_string(display_msg4);
	msdelay(5000);
	
	lcd_init();
	lcd_cmd(0x80);
	msdelay(4);
	lcd_write_string(display_msg5);
	lcd_cmd(0xC0);
	msdelay(4);
	P1 = 0x00;
	lcd_write_string(display_msg6);
	msdelay(1000);

	sort(input_array);

	for(i=0;i<5;i++)
	{
		P1 = swap(input_array[i]);
		msdelay(5000);
		P1 = 0x00;
		msdelay(1000);
	}

	P1 = 0xFF;
	lcd_init();
	lcd_cmd(0x80);
	msdelay(4);
	lcd_write_string(display_msg7);
	lcd_cmd(0xC0);
	msdelay(4);
	lcd_write_string(display_msg8);
	msdelay(5000);
	P1 = (P1 & 0x0F);
	
	number = P1;
	P1 = 0x00;
	lcd_init();
	msdelay(1000);
	
	found = 0;
	for(i=0;i<5;i++)
	{
		if(input_array[i] == number)
		{
			found = 1;
			index = i;
		}
	}
	
	if(found)
	{
		P1 = 16*(index+1);
		lcd_init();
		lcd_cmd(0x80);
		msdelay(4);
		lcd_write_string(display_msg9);
		msdelay(5000);
	}
	
	if(!found)
	{
		P1 = 0xF0;
		lcd_init();
		lcd_cmd(0x80);
		msdelay(4);
		lcd_write_string(display_msg10);
		lcd_cmd(0xC0);
		msdelay(4);
		lcd_write_string(display_msg11);
		msdelay(5000);
	}
	
	while(1);
		
}